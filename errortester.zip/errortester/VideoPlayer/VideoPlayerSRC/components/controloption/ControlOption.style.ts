import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    marginRight: 2,
    marginVertical: 2,
    alignSelf: 'flex-start',
  },
});
