import React, { PureComponent,useEffect,Component, useState  } from 'react';
import { StyleSheet, Text, View,Button,Linking, Platform, Dimensions,Image } from 'react-native';
import {PlayerConfiguration, THEOplayerView} from 'react-native-theoplayer';
//import { VideoPlayerUI } from "./VideoPlayerUI"


const license = Platform.select(
  {
  'android': 'sZP7IYe6T6fc3lhoIKxK0ZkKCDarFSakTSa-CSbk0Zk1CL0o0uAg0DfLTue6FOPlUY3zWokgbgjNIOf9flbrISRrTDatFS46CLa-3uai3Zz_ISggFSxg3ShoIu0kTQBz3ZfVfK4_bQgZCYxNWoryIQXzImf90SCk0Sbz3uRi0u5i0Oi6Io4pIYP1UQgqWgjeCYxgflEc3lar0lhz0lhi0LfrFOPeWok1dDrLYtA1Ioh6TgV6v6fVfKcqCoXVdQjLUOfVfGxEIDjiWQXrIYfpCoj-fgzVfKxqWDXNWG3ybojkbK3gflNWf6E6FOPVWo31WQ1qbta6FOPzdQ4qbQc1sD4ZFK3qWmPUFOPLIQ-LflNWfK1zWDikfgzVfG3gWKxydDkibK4LbogqW6f9UwPkIYz', // insert Android THEOplayer license here
  'ios': undefined,     // insert iOS THEOplayer license here
  'web': 'sZP7IYe6T6fc3lhoIKxK0ZkKCDarFSakTSa-CSbk0Zk1CL0o0uAg0DfLTue6FOPlUY3zWokgbgjNIOf9flbrISRrTDatFS46CLa-3uai3Zz_ISggFSxg3ShoIu0kTQBz3ZfVfK4_bQgZCYxNWoryIQXzImf90SCk0Sbz3uRi0u5i0Oi6Io4pIYP1UQgqWgjeCYxgflEc3lar0lhz0lhi0LfrFOPeWok1dDrLYtA1Ioh6TgV6v6fVfKcqCoXVdQjLUOfVfGxEIDjiWQXrIYfpCoj-fgzVfKxqWDXNWG3ybojkbK3gflNWf6E6FOPVWo31WQ1qbta6FOPzdQ4qbQc1sD4ZFK3qWmPUFOPLIQ-LflNWfK1zWDikfgzVfG3gWKxydDkibK4LbogqW6f9UwPkIYz',     // insert Web THEOplayer license here
  });

const playerConfig: PlayerConfiguration = {
    license,
    chromeless:true,
  };

  const source = {
    sources: [
      {
        src: 'https://static.videezy.com/system/resources/previews/000/000/168/original/Record.mp4',
        type: 'application/dash+mp4',
      },
    ],
  };

function VideoPlayer(){

  return (
    <View>
      <THEOplayerView config={playerConfig} source={source} paused={false} />
    </View>
  );

}
export default VideoPlayer;
