import PlayButton from './play.png';
import FullScreenIcon from './fullscreen.png';
import FullScreenExitIcon from './fullscreen-exit.png';
import SubtitlesIcon from './subtitles.png';
import MutedIcon from './muted.png';
import UnMutedIcon from './unmuted.png';
import AudioIcon from './audio.png';
import PauseIcon from './pause.png';
export { PlayButton, FullScreenIcon, FullScreenExitIcon, SubtitlesIcon, AudioIcon, MutedIcon, UnMutedIcon,PauseIcon };
