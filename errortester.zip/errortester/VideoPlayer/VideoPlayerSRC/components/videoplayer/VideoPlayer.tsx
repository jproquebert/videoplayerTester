import React, { PureComponent } from 'react';
import {
  PlayerError,
  TextTrack,
  DurationChangeEvent,
  TimeUpdateEvent,
  ErrorEvent,
  LoadedMetadataEvent,
  ProgressEvent,
  THEOplayerView,
  MediaTrack,
  TimeRange,
  SourceDescription,
  PlayerConfiguration,
} from 'react-native-theoplayer';
import ALL_SOURCES from '../../res/sources.json';

import { Platform, View,Text } from 'react-native';
import styles from './VideoPlayer.style';
import { VideoPlayerUI } from './VideoPlayerUI';

const TAG = 'VideoPlayer';

const SOURCES = ALL_SOURCES.filter((source) => source.os.indexOf(Platform.OS) >= 0);

export interface VideoPlayerProps {
  config?: PlayerConfiguration;
}

interface VideoPlayerState {
  srcIndex: number;
  playbackRate: number;
  volume: number;
  muted: boolean;
  duration: number;
  seekable: TimeRange[];
  currentTime: number;
  paused: boolean;
  fullscreen: boolean;
  showLoadingIndicator: boolean;
  textTracks: TextTrack[];
  videoTracks: MediaTrack[];
  audioTracks: MediaTrack[];
  selectedTextTrack: number | undefined;
  selectedVideoTrack: number | undefined;
  selectedAudioTrack: number | undefined;
  error: PlayerError | undefined;
}

export class VideoPlayer extends PureComponent<VideoPlayerProps, VideoPlayerState> {
  private static initialState: VideoPlayerState = {
    srcIndex: 0,
    playbackRate: 1,
    volume: 1,
    muted: false,
    duration: Number.NaN,
    currentTime: 0.0,
    seekable: [],
    paused: true,
    fullscreen: false,
    showLoadingIndicator: false,
    textTracks: [],
    videoTracks: [],
    audioTracks: [],
    selectedTextTrack: undefined,
    selectedVideoTrack: undefined,
    selectedAudioTrack: undefined,
    error: undefined,
  };

  private video!: THEOplayerView;

  constructor(props: VideoPlayerProps) {
    super(props);
    this.state = VideoPlayer.initialState;
  }

  private logEvent = (eventName: string) => (data?: unknown) => {
    if (data) {
      console.log(TAG, eventName, JSON.stringify(data));
    } else {
      console.log(TAG, eventName);
    }
  };

  private onLoadStart = () => {
    console.log(TAG, 'loadstart');
    this.setState({ error: undefined });
  };

  private onLoadedMetadata = (data: LoadedMetadataEvent) => {
    console.log(TAG, 'loadedmetadata', JSON.stringify(data));
    this.setState({
      duration: data.duration,
      textTracks: data.textTracks,
      audioTracks: data.audioTracks,
      videoTracks: data.videoTracks,
      selectedTextTrack: data.selectedTextTrack,
      selectedVideoTrack: data.selectedVideoTrack,
      selectedAudioTrack: data.selectedAudioTrack,
    });
  };

  private onPause = () => {
    console.log(TAG, 'pause');
    this.setState({ paused: true });
  };

  private onTimeUpdate = (data: TimeUpdateEvent) => {
    const { currentTime, currentProgramDateTime } = data;
    console.log(TAG, 'timeupdate', currentTime, currentProgramDateTime);
    this.setState({ currentTime });
  };

  private onDurationChange = (data: DurationChangeEvent) => {
    const { duration } = data;
    console.log(TAG, 'durationchange', duration);
    this.setState({ duration });
  };

  private onProgress = (data: ProgressEvent) => {

      const { seekable } = data;
      /*const stuff = {
        end:parseFloat(seekable[0].end),
        start:parseFloat(seekable[0].start),
      }*/
      //var x = JSON.stringify(seekable[0]);
      console.log(TAG, 'progress', seekable);
      this.setState({seekable});

  };

  private onError = (event: ErrorEvent) => {
    const { error } = event;
    this.setState({ error });
  };

  private onBufferingStateChange = (isBuffering: boolean) => {
    this.setState({ showLoadingIndicator: isBuffering });
  };

  private seek = (time: number) => {
    console.log(TAG, 'Seeking to', time);
    this.video.seek(time);
  };

  private onUISelectTextTrack = (uid: number | undefined) => {
    this.setState({ selectedTextTrack: uid });
  };

  private onUISelectAudioTrack = (uid: number | undefined) => {
    this.setState({ selectedAudioTrack: uid });
  };

  private onUISelectVideoTrack = (uid: number | undefined) => {
    this.setState({ selectedVideoTrack: uid });
  };

  private onUISetPlayPause = (paused: boolean) => {
    this.setState({ paused });
  };

  private onUISelectSource = (srcIndex: number) => {
    this.setState({ ...VideoPlayer.initialState, srcIndex });
  };

  private onUISetFullscreen = (fullscreen: boolean) => {
    this.setState({ fullscreen });
  };

  private onUISetMuted = (muted: boolean) => {
    this.setState({ muted });
  };

  private onUISetPlaybackRate = (playbackRate: number) => {
    this.setState({ playbackRate });
  };

  private onUISetVolume = (volume: number) => {
    this.setState({ volume });
  };

  render() {
    const {
      srcIndex,
      error,
      playbackRate,
      paused,
      volume,
      muted,
      fullscreen,
      showLoadingIndicator,
      duration,
      seekable,
      currentTime,
      textTracks,
      selectedTextTrack,
      videoTracks,
      selectedVideoTrack,
      audioTracks,
      selectedAudioTrack,
    } = this.state;

    const { config } = this.props;
    const chromeless = config?.chromeless;
    const source = SOURCES[srcIndex].source as SourceDescription;

    return (
      <View style={styles.container}>
        <View>
          <THEOplayerView
          ref={(ref: THEOplayerView) => {
            this.video = ref;
          }}
          config={config}
          source={source}
          fullscreen={fullscreen}
          style={styles.fullScreen}
          playbackRate={playbackRate}
          paused={paused}
          volume={volume}
          muted={muted}
          selectedTextTrack={selectedTextTrack}
          selectedAudioTrack={selectedAudioTrack}
          selectedVideoTrack={selectedVideoTrack}
          onBufferingStateChange={this.onBufferingStateChange}
          onSourceChange={this.logEvent('sourcechange')}
          onLoadStart={this.onLoadStart}
          onLoadedMetadata={this.onLoadedMetadata}
          onLoadedData={this.logEvent('loadeddata')}
          onReadyStateChange={this.logEvent('readystatechange')}
          onError={this.onError}
          onProgress={this.onProgress}
          onPlay={this.logEvent('play')}
          onPlaying={this.logEvent('playing')}
          onPause={this.onPause}
          onSeeking={this.logEvent('seeking')}
          onSeeked={this.logEvent('seeked')}
          onEnded={this.logEvent('ended')}
          onTimeUpdate={this.onTimeUpdate}
          onDurationChange={this.onDurationChange}
        />
          <VideoPlayerUI
        sources={SOURCES}
        srcIndex={srcIndex}
        playbackRate={playbackRate}
        volume={volume}
        muted={muted}
        duration={duration}
        seekable={seekable}
        currentTime={currentTime}
        paused={paused}
        fullscreen={fullscreen}
        showLoadingIndicator={showLoadingIndicator}
        textTracks={textTracks}
        videoTracks={videoTracks}
        audioTracks={audioTracks}
        selectedTextTrack={selectedTextTrack}
        selectedVideoTrack={selectedVideoTrack}
        selectedAudioTrack={selectedAudioTrack}
        error={error}
        onSetPlayPause={this.onUISetPlayPause}
        onSeek={this.seek}
        onSelectSource={this.onUISelectSource}
        onSelectTextTrack={this.onUISelectTextTrack}
        onSelectAudioTrack={this.onUISelectAudioTrack}
        onSelectVideoTrack={this.onUISelectVideoTrack}
        onSetFullScreen={this.onUISetFullscreen}
        onSetMuted={this.onUISetMuted}
        onSetPlaybackRate={this.onUISetPlaybackRate}
        onSetVolume={this.onUISetVolume}
      />
        </View>
      </View>
    );
  }
}
