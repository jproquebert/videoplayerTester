import React from "react";
import {View,StyleSheet,Dimensions } from "react-native";
const {width, height} = Dimensions.get('window');

import { VideoPlayer } from './VideoPlayer/VideoPlayerSRC/components/videoplayer/VideoPlayer';
import type { PlayerConfiguration } from 'react-native-theoplayer';
const license = Platform.select(
  {
  'android': 'sZP7IYe6T6P13oIgCof_0mzi0SRZFSazTSR-Clg63mzi3KCcIQxg0KfiISC6FOPlUY3zWokgbgjNIOf9flbrISRrTDatFS46CLa-3uai3Zz_ISggFSxg3ShoIu0kTQBz3ZfVfK4_bQgZCYxNWoryIQXzImf90SCk3uhr3l5i0u5i0Oi6Io4pIYP1UQgqWgjeCYxgflEc3lhL3u5c3LRL0lRcFOPeWok1dDrLYtA1Ioh6TgV6v6fVfKcqCoXVdQjLUOfVfGxEIDjiWQXrIYfpCoj-fgzVfKxqWDXNWG3ybojkbK3gflNWf6E6FOPVWo31WQ1qbta6FOPzdQ4qbQc1sD4ZFK3qWmPUFOPLIQ-LflNWfKXpIwPqdDa6Ymi6bo4pIXjNWYAZIY3LdDjpflNzbG4gya', // insert Android THEOplayer license here
  });

  const playerConfig: PlayerConfiguration = {
      license,
      chromeless:true
    };

function test(){

  return (
    <View style={styles.container}>
      <View style={styles.player}>
        <VideoPlayer config={playerConfig} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent:'center',
  },
  player:{
    height:height,
  }
});

export default test;
